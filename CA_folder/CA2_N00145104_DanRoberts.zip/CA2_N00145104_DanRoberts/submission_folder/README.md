https://github.com/DannyRoberts95/Generative-Design/tree/master/03_Type/05_polygon_links
